package com.saheb.jarvez;

import android.content.Context;
import android.media.AudioManager;
import android.view.KeyEvent;

public class MediaController {
    private final AudioManager audio;
    public MediaController(Context c) { audio = (AudioManager)c.getSystemService(Context.AUDIO_SERVICE); }

    public void volumeUp() { if (audio != null) audio.adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); }
    public void volumeDown() { if (audio != null) audio.adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); }
    public void mute() { if (audio != null) audio.adjustVolume(AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); }

    public void mediaPlayPause() {
        if (audio == null) return;
        audio.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE));
        audio.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE));
    }
}
