package com.saheb.jarvez;

import android.content.Context;
import android.database.Cursor;
import android.provider.ContactsContract;
import java.util.ArrayList;
import java.util.List;

public class ContactManager {
    public static class Match {
        public final String name, number;
        public Match(String name, String number) { this.name=name; this.number=number; }
    }

    public static List<Match> find(Context c, String query) {
        List<Match> out = new ArrayList<>();
        if (query == null) return out;
        Cursor x = c.getContentResolver().query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                         ContactsContract.CommonDataKinds.Phone.NUMBER},
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            new String[]{"%" + query.trim() + "%"}, null);
        try {
            if (x != null) while (x.moveToNext() && out.size() < 5)
                out.add(new Match(x.getString(0), x.getString(1)));
        } finally { if (x != null) x.close(); }
        return out;
    }
}
