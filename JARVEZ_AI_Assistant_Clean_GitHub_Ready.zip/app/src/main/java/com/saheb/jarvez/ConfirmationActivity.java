package com.saheb.jarvez;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.telephony.SmsManager;
import android.widget.*;
import java.util.ArrayList;
import java.util.Locale;

public class ConfirmationActivity extends Activity {
    private SpeechRecognizer recognizer;
    private String type, number, body, name;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_confirmation);
        Intent in=getIntent(); type=in.getStringExtra("type"); number=in.getStringExtra("number");
        body=in.getStringExtra("body"); name=in.getStringExtra("name");
        ((TextView)findViewById(R.id.question)).setText(in.getStringExtra("question"));

        findViewById(R.id.yesButton).setOnClickListener(v->execute());
        findViewById(R.id.noButton).setOnClickListener(v->finish());
        findViewById(R.id.voiceButton).setOnClickListener(v->listenForDecision());

        if (SpeechRecognizer.isRecognitionAvailable(this)) listenForDecision();
    }

    private void listenForDecision() {
        if (recognizer!=null) recognizer.destroy();
        recognizer=SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onResults(Bundle b) {
                ArrayList<String> r=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if(r==null||r.isEmpty()) return;
                String s=r.get(0).toLowerCase(Locale.ROOT);
                if(isYes(s)) execute();
                else if(isNo(s)) finish();
            }
            public void onReadyForSpeech(Bundle b){((TextView)findViewById(R.id.voiceStatus)).setText("सुन रहा हूँ… बोलिए हाँ या नहीं");}
            public void onError(int e){((TextView)findViewById(R.id.voiceStatus)).setText("फिर से बोलें या button दबाएँ");}
            public void onBeginningOfSpeech(){} public void onRmsChanged(float x){} public void onBufferReceived(byte[] b){}
            public void onEndOfSpeech(){} public void onPartialResults(Bundle b){} public void onEvent(int a,Bundle b){}
        });
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"hi-IN");
        recognizer.startListening(i);
    }

    private boolean isYes(String s) {
        return s.contains("yes")||s.contains("haan")||s.contains("हाँ")||s.contains("हां")||
               s.contains("कर दो")||s.contains("कर देना")||s.contains("call kar do")||s.contains("भेज दो");
    }
    private boolean isNo(String s) {
        return s.contains("no")||s.contains("nahi")||s.contains("nahin")||s.contains("नहीं")||
               s.contains("नही")||s.contains("cancel")||s.contains("रहने दो");
    }

    private void execute() {
        if ("CALL".equals(type)) {
            if (checkSelfPermission(Manifest.permission.CALL_PHONE)!=PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, 41); return;
            }
            try {
                startActivity(new Intent(Intent.ACTION_CALL, Uri.parse("tel:"+number)));
                finish();
            } catch(Exception e) { Toast.makeText(this,"Call नहीं हो सका",Toast.LENGTH_SHORT).show(); }
        } else if ("SMS".equals(type)) {
            if (checkSelfPermission(Manifest.permission.SEND_SMS)!=PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.SEND_SMS}, 42); return;
            }
            try {
                SmsManager.getDefault().sendTextMessage(number,null,body,null,null);
                Toast.makeText(this,"Message भेज दिया",Toast.LENGTH_SHORT).show();
                finish();
            } catch(Exception e) { Toast.makeText(this,"Message नहीं भेजा जा सका",Toast.LENGTH_SHORT).show(); }
        }
    }

    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g) {
        super.onRequestPermissionsResult(r,p,g);
        if((r==41||r==42)&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED) execute();
    }
    @Override protected void onDestroy(){if(recognizer!=null){recognizer.destroy();recognizer=null;}super.onDestroy();}
}
