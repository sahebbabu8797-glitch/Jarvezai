package com.saheb.jarvez;

import android.app.admin.DeviceAdminReceiver;

public class JarvezDeviceAdminReceiver extends DeviceAdminReceiver {
}
