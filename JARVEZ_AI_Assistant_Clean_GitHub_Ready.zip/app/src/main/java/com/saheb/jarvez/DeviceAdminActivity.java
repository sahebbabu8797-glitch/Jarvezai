package com.saheb.jarvez;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class DeviceAdminActivity extends Activity {
    private DeviceLockManager lockManager;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        lockManager = new DeviceLockManager(this);
        TextView v = new TextView(this);
        v.setText("JARVEZ screen lock permission\n\nPlease enable Device Administrator for JARVEZ. You can then say: Hey Jarvis, phone lock karo.");
        v.setPadding(40, 80, 40, 40);
        setContentView(v);
        if (lockManager.isAdminActive()) {
            lockManager.lockNow();
            finish();
        } else {
            lockManager.requestActivation(this);
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == DeviceLockManager.REQUEST_ENABLE_ADMIN) {
            if (lockManager.isAdminActive()) lockManager.lockNow();
            finish();
        }
    }
}
