package com.saheb.jarvez;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;

public class DeviceLockManager {
    public static final int REQUEST_ENABLE_ADMIN = 2201;
    private final Context context;
    private final DevicePolicyManager dpm;
    private final ComponentName admin;

    public DeviceLockManager(Context context) {
        this.context = context.getApplicationContext();
        dpm = (DevicePolicyManager) this.context.getSystemService(Context.DEVICE_POLICY_SERVICE);
        admin = new ComponentName(this.context, JarvezDeviceAdminReceiver.class);
    }

    public boolean isAdminActive() {
        return dpm != null && dpm.isAdminActive(admin);
    }

    public boolean lockNow() {
        if (!isAdminActive()) return false;
        dpm.lockNow();
        return true;
    }

    public void requestActivation(Activity activity) {
        Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin);
        intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "JARVEZ needs Device Administrator permission to lock the phone when you say a lock command.");
        activity.startActivityForResult(intent, REQUEST_ENABLE_ADMIN);
    }
}
