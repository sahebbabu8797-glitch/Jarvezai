package com.saheb.jarvez;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_MIC = 100;
    private static final int REQ_FEATURES = 101;
    private static final int REQ_NOTIFICATION = 102;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        findViewById(R.id.startButton).setOnClickListener(v -> startJarvez());
        findViewById(R.id.stopButton).setOnClickListener(v -> stopJarvez());
        findViewById(R.id.featuresButton).setOnClickListener(v -> requestPhoneFeatures());
        findViewById(R.id.lockButton).setOnClickListener(v -> enableScreenLock());
    }

    private void startJarvez() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATION);
            return;
        }
        Intent i = new Intent(this, JarvezVoiceService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        ((TextView)findViewById(R.id.status)).setText("JARVEZ ACTIVE — say: Hey Jarvez");
    }

    private void requestPhoneFeatures() {
        if (Build.VERSION.SDK_INT < 23) return;
        List<String> missing = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.READ_CONTACTS);
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.CALL_PHONE);
        if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.SEND_SMS);
        if (missing.isEmpty()) {
            ((TextView)findViewById(R.id.status)).setText("Phone features are enabled");
            return;
        }
        requestPermissions(missing.toArray(new String[0]), REQ_FEATURES);
    }

    private void enableScreenLock() {
        DeviceLockManager manager = new DeviceLockManager(this);
        if (manager.isAdminActive()) {
            manager.lockNow();
        } else {
            startActivity(new Intent(this, DeviceAdminActivity.class));
        }
    }

    private void stopJarvez() {
        stopService(new Intent(this, JarvezVoiceService.class));
        ((TextView)findViewById(R.id.status)).setText("JARVEZ stopped");
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode, permissions, grants);
        if (requestCode == REQ_MIC) {
            boolean mic = Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
            if (mic) startJarvez(); else ((TextView)findViewById(R.id.status)).setText("Microphone permission is required");
        } else if (requestCode == REQ_NOTIFICATION) {
            // Notification permission is useful for the foreground-service indicator, but it is not the voice permission.
            Intent i = new Intent(this, JarvezVoiceService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            ((TextView)findViewById(R.id.status)).setText("JARVEZ ACTIVE — say: Hey Jarvez");
        } else if (requestCode == REQ_FEATURES) {
            ((TextView)findViewById(R.id.status)).setText("Phone permissions updated");
        }
    }
}
