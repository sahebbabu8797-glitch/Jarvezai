package com.saheb.jarvez;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CommandProcessor {
    private final Context context;
    private final TtsManager tts;
    private final FlashController flash;
    private final MediaController media;
    private final AppLauncher apps;
    private final DeviceLockManager deviceLock;

    public CommandProcessor(Context c, TtsManager tts) {
        context=c.getApplicationContext(); this.tts=tts;
        flash=new FlashController(context); media=new MediaController(context); apps=new AppLauncher(context); deviceLock=new DeviceLockManager(context);
    }

    public boolean process(String raw) {
        if (raw == null) return false;
        String c=raw.trim().toLowerCase(Locale.ROOT);

        if (c.contains("lock phone") || c.contains("lock screen") || c.contains("phone lock") ||
            c.contains("screen lock") || c.contains("फोन लॉक") || c.contains("फोन को लॉक") ||
            c.contains("स्क्रीन लॉक") || c.contains("स्क्रीन को लॉक") || c.contains("लॉक कर दो")) {
            if (deviceLock.isAdminActive()) {
                deviceLock.lockNow();
            } else {
                try {
                    Intent i = new Intent(context, DeviceAdminActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(i);
                } catch (Exception e) {
                    tts.speak("Screen lock permission enable करें");
                }
            }
            return true;
        }

        if (c.contains("flash on") || c.contains("torch on") || c.contains("flashlight on") ||
            c.contains("फ्लैश ऑन") || c.contains("टॉर्च ऑन")) {
            tts.speak(flash.setFlash(true) ? "Flash on" : "Flash नहीं हो सका"); return true;
        }
        if (c.contains("flash off") || c.contains("torch off") || c.contains("flashlight off") ||
            c.contains("फ्लैश ऑफ") || c.contains("टॉर्च ऑफ")) {
            tts.speak(flash.setFlash(false) ? "Flash off" : "Flash नहीं हो सका"); return true;
        }

        if (c.contains("volume up") || c.contains("volume बढ़ा") || c.contains("आवाज़ बढ़ा")) { media.volumeUp(); tts.speak("Volume बढ़ा दिया"); return true; }
        if (c.contains("volume down") || c.contains("volume कम") || c.contains("आवाज़ कम")) { media.volumeDown(); tts.speak("Volume कम कर दिया"); return true; }
        if (c.equals("mute") || c.contains(" mute") || c.startsWith("mute ") || c.contains("म्यूट")) { media.mute(); tts.speak("Mute कर दिया"); return true; }
        if (c.equals("play") || c.equals("pause") || c.contains("play music") || c.contains("play media") ||
            c.contains("pause music") || c.contains("pause media") || c.equals("प्ले") || c.equals("पॉज़") ||
            c.contains("मीडिया प्ले") || c.contains("मीडिया पॉज़")) { media.mediaPlayPause(); return true; }

        if (c.contains("wifi") || c.contains("wi-fi") || c.contains("वाई फाई") || c.contains("वाई-फाई")) { apps.openSettings("wifi"); return true; }
        if (c.contains("bluetooth")) { apps.openSettings("bluetooth"); return true; }
        if (c.contains("display")) { apps.openSettings("display"); return true; }
        if (c.contains("sound")) { apps.openSettings("sound"); return true; }
        if (c.equals("settings") || c.contains("open settings") || c.contains("सेटिंग")) { apps.openSettings("settings"); return true; }

        String[][] appAliases={
                {"youtube","यूट्यूब"},{"whatsapp","व्हाट्सऐप","व्हाट्सएप"},{"instagram","इंस्टाग्राम"},
                {"facebook","फेसबुक"},{"chrome","क्रोम"},{"camera","कैमरा"},{"gemini","जेमिनी"}
        };
        for (String[] aliases : appAliases) {
            for (String alias : aliases) {
                if (c.contains(alias)) {
                    if (apps.open(aliases[0])) tts.speak(aliases[0] + " खोल रहा हूँ");
                    else tts.speak("App नहीं मिली");
                    return true;
                }
            }
        }

        if (c.equals("back") || c.equals("go back") || c.equals("पीछे जाओ") || c.equals("वापस जाओ")) {
            // A Service cannot safely inject Android's system Back gesture.
            // Returning to Home is the public-API fallback.
            Intent i=new Intent(Intent.ACTION_MAIN); i.addCategory(Intent.CATEGORY_HOME); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
            tts.speak("Back command के लिए Android public API उपलब्ध नहीं है; Home पर जा रहा हूँ");
            return true;
        }

        Matcher call=Pattern.compile("^(?:call|कॉल)\\s+(.+)$").matcher(c);
        if(call.find()) {
            String name = call.group(1).trim();
            if (name.endsWith(" को")) name = name.substring(0, name.length()-3).trim();
            requestContactAction(name, true, null);
            return true;
        }

        Matcher msg=Pattern.compile("^(?:message|sms|मैसेज|संदेश)\\s+(.+)$").matcher(c);
        if(msg.find()) {
            String rest = msg.group(1).trim();
            String body = "";
            String lowerRest = rest.toLowerCase(Locale.ROOT);
            int split = lowerRest.indexOf(" that ");
            if (split < 0) split = lowerRest.indexOf(" कि ");
            if (split >= 0) {
                body = rest.substring(split + (lowerRest.startsWith(" that ", split) ? 6 : 4)).trim();
                rest = rest.substring(0, split).trim();
            }
            if (rest.endsWith(" को")) rest = rest.substring(0, rest.length()-3).trim();
            if (body.isEmpty()) {
                tts.speak("Message क्या भेजना है? उदाहरण: message Rahul that मैं पाँच मिनट में पहुँच रहा हूँ");
                return true;
            }
            requestContactAction(rest, false, body);
            return true;
        }

        return false;
    }

    private String hindi(String a) {
        if(a.equals("camera")) return "कैमरा";
        if(a.equals("youtube")) return "यूट्यूब";
        if(a.equals("whatsapp")) return "व्हाट्सऐप";
        return a;
    }

    private void requestContactAction(String name, boolean call, String body) {
        if (android.os.Build.VERSION.SDK_INT>=23 &&
            context.checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED) {
            tts.speak("Contacts permission चाहिए। JARVEZ में Enable Call SMS Features दबाएँ"); return;
        }
        java.util.List<ContactManager.Match> m=ContactManager.find(context,name);
        if(m.size()!=1) { tts.speak(m.isEmpty()?"Contact नहीं मिला":"एक से ज्यादा contact मिले"); return; }

        ContactManager.Match x=m.get(0);
        if(call) {
            Intent i=new Intent(context,ConfirmationActivity.class);
            i.putExtra("type","CALL"); i.putExtra("name",x.name); i.putExtra("number",x.number);
            i.putExtra("question",x.name+" को call करूँ?");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(i);
        } else {
            Intent i=new Intent(context,ConfirmationActivity.class);
            i.putExtra("type","SMS"); i.putExtra("name",x.name); i.putExtra("number",x.number);
            i.putExtra("body",body==null?"":body);
            i.putExtra("question",x.name+" को message भेजूँ?");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(i);
        }
    }
}
