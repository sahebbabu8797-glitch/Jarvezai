package com.saheb.jarvez;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import java.util.ArrayList;
import java.util.Locale;

public class JarvezVoiceService extends Service {
    public static final String ACTION_STOP = "com.saheb.jarvez.STOP";
    private static final int NOTIFICATION_ID = 7001;
    private SpeechRecognizer recognizer;
    private TtsManager tts;
    private CommandProcessor processor;
    private boolean running;
    private boolean listening;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onCreate() {
        super.onCreate();
        tts = new TtsManager(this);
        processor = new CommandProcessor(this, tts);
        createNotification();
    }

    private void createNotification() {
        String channel = "jarvez_voice";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(
                    new NotificationChannel(channel, "JARVEZ Voice", NotificationManager.IMPORTANCE_LOW));
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, channel) : new Notification.Builder(this);
        b.setContentTitle("JARVEZ is active")
         .setContentText("Say: Hey Jarvez / Jarvez")
         .setSmallIcon(android.R.drawable.ic_btn_speak_now)
         .setOngoing(true);
        startForeground(NOTIFICATION_ID, b.build());
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        running = true;
        scheduleListen(100);
        return START_STICKY;
    }

    private void scheduleListen(long delay) {
        handler.removeCallbacksAndMessages(null);
        if (running) handler.postDelayed(this::listen, delay);
    }

    private void listen() {
        if (!running || listening) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            if (tts != null) tts.speak("Speech recognition उपलब्ध नहीं है");
            scheduleListen(3000);
            return;
        }
        listening = true;
        if (recognizer != null) recognizer.destroy();
        try {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onResults(Bundle b) {
                    listening = false;
                    ArrayList<String> results = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (results != null && !results.isEmpty()) handle(results.get(0));
                    scheduleListen(500);
                }
                @Override public void onError(int error) {
                    listening = false;
                    scheduleListen(error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 1500 : 700);
                }
                @Override public void onReadyForSpeech(Bundle b) {}
                @Override public void onBeginningOfSpeech() {}
                @Override public void onRmsChanged(float rmsdB) {}
                @Override public void onBufferReceived(byte[] buffer) {}
                @Override public void onEndOfSpeech() {}
                @Override public void onPartialResults(Bundle b) {}
                @Override public void onEvent(int eventType, Bundle params) {}
            });

            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN");
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
            recognizer.startListening(i);
        } catch (Exception e) {
            listening = false;
            scheduleListen(1500);
        }
    }

    private void handle(String text) {
        if (text == null) return;
        String raw = text.trim();
        String s = raw.toLowerCase(Locale.ROOT);
        boolean wake = s.contains("hey jarvez") || s.contains("hey jarvis") ||
                s.matches(".*\\bjarvez\\b.*") || s.matches(".*\\bjarvis\\b.*") ||
                s.contains("हे जारवेज") || s.contains("हे जार्वेज") || s.contains("जारवेज");
        if (!wake) return;

        String command = s.replace("hey jarvez", "")
                .replace("hey jarvis", "")
                .replace("jarvez", "")
                .replace("jarvis", "")
                .replace("हे जारवेज", "")
                .replace("हे जार्वेज", "")
                .replace("जारवेज", "")
                .trim();

        if (command.isEmpty()) {
            tts.speak("जी, बोलिए");
            return;
        }
        if (!processor.process(command)) tts.speak("यह command अभी उपलब्ध नहीं है");
    }

    @Override public void onDestroy() {
        running = false;
        listening = false;
        handler.removeCallbacksAndMessages(null);
        if (recognizer != null) { recognizer.destroy(); recognizer = null; }
        if (tts != null) { tts.shutdown(); tts = null; }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
