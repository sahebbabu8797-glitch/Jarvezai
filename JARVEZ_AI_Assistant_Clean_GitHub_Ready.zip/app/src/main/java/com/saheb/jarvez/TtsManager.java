package com.saheb.jarvez;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import java.util.Locale;

public class TtsManager implements TextToSpeech.OnInitListener {
    private final TextToSpeech tts;
    public TtsManager(Context context) { tts = new TextToSpeech(context.getApplicationContext(), this); }
    public void onInit(int status) { if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi", "IN")); }
    public void speak(String text) { if (text != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvez"); }
    public void shutdown() { tts.stop(); tts.shutdown(); }
}
