package com.saheb.jarvez;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

public class AppLauncher {
    private final Context context;
    public AppLauncher(Context c) { context = c.getApplicationContext(); }

    public boolean open(String name) {
        String n = name.toLowerCase(java.util.Locale.ROOT);
        if (n.contains("यूट्यूब")) n = "youtube";
        else if (n.contains("व्हाट्सऐप") || n.contains("व्हाट्सएप")) n = "whatsapp";
        else if (n.contains("इंस्टाग्राम")) n = "instagram";
        else if (n.contains("फेसबुक")) n = "facebook";
        else if (n.contains("क्रोम")) n = "chrome";
        else if (n.contains("कैमरा")) n = "camera";
        else if (n.contains("जेमिनी")) n = "gemini";
        String pkg = null;
        if (n.contains("youtube")) pkg = "com.google.android.youtube";
        else if (n.contains("whatsapp")) pkg = "com.whatsapp";
        else if (n.contains("instagram")) pkg = "com.instagram.android";
        else if (n.contains("facebook")) pkg = "com.facebook.katana";
        else if (n.contains("chrome")) pkg = "com.android.chrome";
        else if (n.contains("camera")) return openCamera();
        else if (n.contains("gemini")) {
            pkg = findFirstInstalled("com.google.android.apps.gemini", "com.google.android.apps.bard");
        }
        if (pkg == null) return false;
        Intent i = context.getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) return false;
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(i);
        return true;
    }

    private String findFirstInstalled(String... packages) {
        for (String p : packages) {
            if (context.getPackageManager().getLaunchIntentForPackage(p) != null) return p;
        }
        return null;
    }

    public boolean openCamera() {
        try {
            Intent i = new Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
            return true;
        } catch (Exception e) { return false; }
    }

    public boolean openSettings(String target) {
        try {
            String action = android.provider.Settings.ACTION_SETTINGS;
            String t = target.toLowerCase(java.util.Locale.ROOT);
            if (t.contains("wifi")) action = android.provider.Settings.ACTION_WIFI_SETTINGS;
            else if (t.contains("bluetooth")) action = android.provider.Settings.ACTION_BLUETOOTH_SETTINGS;
            else if (t.contains("display")) action = android.provider.Settings.ACTION_DISPLAY_SETTINGS;
            else if (t.contains("sound")) action = android.provider.Settings.ACTION_SOUND_SETTINGS;
            Intent i = new Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
            return true;
        } catch (Exception e) { return false; }
    }
}
