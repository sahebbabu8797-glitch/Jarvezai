# JARVEZ does not require custom R8/ProGuard rules.
