# JARVEZ AI ASSISTANT — Build-Compatible Android Project

## Build configuration
- Android Gradle Plugin: 8.6.1
- Gradle: 8.7
- Compile/Target SDK: 35
- Min SDK: 26
- Java: 17
- No external runtime libraries are required.

For a cloud builder, select **APK** and build `assembleDebug` first. The release variant is also configured.

---

# JARVEZ AI ASSISTANT — checked build

## Included
- Android Java project, package `com.saheb.jarvez`
- Foreground microphone service with persistent notification
- “Hey Jarvez” / “Jarvez” wake-word style flow
- Hindi/Hinglish/English speech recognition
- Text-to-speech
- YouTube, WhatsApp, Instagram, Facebook, Chrome, Camera and Gemini launch shortcuts
- Settings / Wi‑Fi / Bluetooth / Display / Sound shortcuts
- Flash/torch ON/OFF
- Volume up/down, mute, media play/pause
- Contact lookup
- Call and SMS with explicit confirmation
- Spoken YES/NO confirmation: “हाँ”, “हाँ कर दो”, “haan kar do”, “नहीं”, “cancel”
- Real Android runtime permissions
- Human-readable notification while microphone service is active
- Included JARVEZ logo asset

## Important Android limitation
This is NOT a privileged Google Assistant replacement. Android's public APIs do not guarantee a system-wide, always-on hotword listener like “Hey Google”. The service must be started by the user and Android/device battery/security rules can stop or restrict background microphone use.

SpeechRecognizer is also not a dedicated low-power hotword engine. This implementation uses repeated recognition sessions, so battery usage and wake-word reliability will vary by device.

## Call/SMS safety
Call and message commands always show/voice-confirm the current action. A permanent silent call bypass is not enabled.

## AI backend
A production AI backend should be added separately. Do not put a private API key directly in the APK. Use a secure backend/proxy or another approved authentication mechanism.

## Build
Open the project in Android Studio, let Gradle sync, then Run/Build APK. Test permissions and microphone behavior on a real Android device.

## Verification note
The project structure, manifest declarations, runtime-permission flow, foreground-service declaration, confirmation flow, and command routing were reviewed. A local Android SDK/Gradle toolchain was not available in this runtime, so a device/Gradle build could not be executed here.

## Screen Lock
JARVEZ supports locking the phone screen with voice commands such as:
- "Hey Jarvis, phone lock karo"
- "Hey Jarvez, lock screen"
- "फोन लॉक कर दो"

The first time, Android requires the user to manually enable JARVEZ as a Device Administrator. After that one-time activation, the voice command can call Android's public `DevicePolicyManager.lockNow()` API. This only locks the screen; it does not change or bypass the PIN, pattern, password, or biometrics.

## Final build notes
This project is native Android Java. Do not upload it to HTML-to-APK sites that require `index.html`. Use a native Android/Gradle source builder or Android Studio.
