UPLOAD THE CONTENTS OF THIS FOLDER, NOT THE ZIP FILE.
The GitHub repository root must contain app/ and .github/.
