# JARVEZ — New GitHub Repository Setup

This ZIP is the complete native Android Java project. Upload the CONTENTS of this folder to a new empty GitHub repository. Do not upload this ZIP as a single file.

## Required root structure

- `.github/workflows/build-apk.yml`
- `app/`
- `gradle/wrapper/gradle-wrapper.properties`
- `build.gradle`
- `settings.gradle`
- `gradle.properties`
- `gradlew`
- `gradlew.bat`
- `code2native.json`

## GitHub mobile steps

1. Create an empty repository at https://github.com/new
2. Keep it empty: do not add README, .gitignore, or license.
3. Extract this ZIP on the phone.
4. Open the extracted project root.
5. Upload the project CONTENTS so that `app/` is at repository root. Do not upload the ZIP itself.
6. Confirm the repository root shows `app/` and `.github/`.
7. Open Actions → Build JARVEZ APK → Run workflow.
8. When the run succeeds, open the run and download the `JARVEZ-debug-apk` artifact.

## Build configuration

- Android Gradle Plugin 8.6.1
- Gradle 8.7
- Java 17
- Compile/Target SDK 35
- Minimum SDK 26
- Application ID `com.saheb.jarvez`

The workflow installs only the required Android SDK packages and does not request the obsolete `tools` package.
